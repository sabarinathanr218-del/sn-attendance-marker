# 📋 SN Attendance Marker

> **Smart Attendance Management App for Class Representatives**
> Built & Designed by **SN**

---

## 🌟 About This App

**SN Attendance Marker** is a free, lightweight mobile web app built specifically for college class representatives. Instead of using WhatsApp notes or ChatGPT to track attendance, class reps can now manage everything in one place — fast, clean, and offline.

---

## ✨ Features

### 🔐 Authentication
- Custom **SN username & password** — no email needed
- Strong password enforcement (7+ chars, letters + numbers)
- **Forgot Password** — reset via class name security check
- **Remember Me** — saves username or full credentials with your permission
- Auto-fill login on next visit

### 👥 Student Management
- Add students with Roll No, Name, Date of Birth, Gender
- Edit or delete any student anytime
- Auto-sorted by roll number
- Search by name or roll number

### ✅ Attendance Marking
- Mark per **Hour / Period** (Hour 1 to Hour 8)
- Three statuses: **Present (P) / Absent (A) / On Duty (OD)**
- Quick "Mark All" buttons for fast entry
- Live count of P / A / OD

### 📊 Summary & Sharing
- Full attendance summary after saving
- **Quick Copy buttons** — copy absent names, OD names, present names, or roll numbers only
- **Share via WhatsApp** or copy to clipboard
- SN branding on shared text

### 📁 History
- View all past attendance records
- Filter by Today / This Week / All Time
- **Edit** any past record
- **Delete** records

### 🏫 Multiple Classes
- Each class rep manages their own class
- No class name duplicates (SC-A + SC-A blocked, SC-A + SC-B allowed)
- Fully isolated — admins only see their own class

### 👑 Founder Dashboard
- View all registered classes across the platform
- Edit class names
- Delete classes
- Open and manage any class

### 📱 PWA — Installable as Mobile App
- Works fully **offline**
- Install on **Android** via Chrome → Add to Home Screen
- Install on **iPhone** via Safari → Share → Add to Home Screen
- Feels like a native app — no app store needed

### 🔒 Security
- Founder account separate from class admins
- Each admin sees only their class
- Data stored locally on device

---

## 🚀 Live Demo

> 🌐 **[sn-attendance.vercel.app](https://sn-attendance.vercel.app)**

**Demo Founder Login:**
- Username: `SN_founder`
- Password: `SN@admin1`

---

## 🛠️ Tech Stack

| Technology | Purpose |
|---|---|
| React 18 | UI Framework |
| Vite | Build Tool |
| LocalStorage | Offline Data Storage |
| PWA | Mobile Installation |
| Vercel | Hosting & Deployment |

---

## 📦 Installation & Setup

### Prerequisites
- Node.js 18+ installed
- npm or yarn

### Run Locally
```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/sn-attendance.git

# 2. Go into the folder
cd sn-attendance

# 3. Install dependencies
npm install

# 4. Start the app
npm run dev

# 5. Open in browser
# http://localhost:3000
```

### Build for Production
```bash
npm run build
```

---

## 🌐 Deploy on Vercel (Free)

1. Push this repository to GitHub
2. Go to [vercel.com](https://vercel.com) and sign in with GitHub
3. Click **"Add New Project"**
4. Select this repository
5. Click **Deploy**
6. Your app is live in ~1 minute! 🎉

---

## 📁 Project Structure

```
sn-attendance/
├── index.html          # Main HTML entry point
├── package.json        # Dependencies and scripts
├── vite.config.js      # Vite build configuration
├── .gitignore          # Files to ignore
├── README.md           # This file
└── src/
    ├── main.jsx        # React entry point
    └── App.jsx         # Full application code
```

---

## 📲 How to Install as Mobile App

### Android 📱
1. Open app link in **Chrome**
2. Tap **3 dots menu** (top right)
3. Tap **"Add to Home Screen"**
4. Tap **Add** ✅

### iPhone 🍎
1. Open app link in **Safari**
2. Tap the **Share button** ⬆️
3. Tap **"Add to Home Screen"**
4. Tap **Add** ✅

---

## 🔐 Default Founder Account

| Field | Value |
|---|---|
| Username | `SN_founder` |
| Password | `SN@admin1` |

> ⚠️ Change the founder password after first login for security.

---

## 📄 License

This project is private and built by **SN**.
All rights reserved © 2025 SN

---

## 💬 Contact & Support

For any issues or feature requests, contact the founder through the app.

---

<div align="center">
  <strong>Built with ❤️ by SN</strong><br/>
  <em>Smart Attendance for Every Class Rep</em>
</div>
